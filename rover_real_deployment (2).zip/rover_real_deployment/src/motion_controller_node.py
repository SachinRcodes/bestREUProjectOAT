#!/usr/bin/env python3
"""
Motion controller v10 - same working steering as before, simplified exit trigger.

DRIVE behavior (no door locked on): fast wall-following, parallel to the
wall (a P-controller holds standoff distance + heading alignment). If the
wall reading shows a gap (farther than normal), slow down to give the
camera/AI time to look at it. Unchanged from the version that worked.

COMMIT: the moment the AI confirms an open door (a single ENTER_OPEN_DOOR
reading is enough), the rover commits and starts a 20-second timer
(COMMIT_DURATION_SEC). For that whole duration it keeps using the SAME
find_deepest_point-based steering that was working before - continuously
aiming at the farthest clear lidar point near the door's bearing, with the
anchor bounded so it can't drift arbitrarily far from where the door was
originally confirmed (a real bug we hit and fixed: it once drifted to
~150deg off, nearly behind the robot). Obstacle avoidance is bypassed only
when close AND well-aligned (exactly as before) to avoid the frame-edge
stuck-oscillation bug; otherwise it's fully active, including a stuck/backup
recovery if front clearance stays too tight for too long.

REMOVED (per request): the doorframe-pattern check (is_at_gap - two near
sides + one far line ahead) that used to decide "have I crossed the
threshold yet." That was a source of repeated bugs (premature/late
triggers). It's no longer needed - the same 20-second timer handles the
whole commit phase, whether it's still approaching, crossing, or already
inside; steering runs continuously throughout regardless.

RECORDING starts at the exact moment of commit. After COMMIT_DURATION_SEC,
it replays everything recorded in reverse (negating both linear and angular
for each entry) - back to the point where it committed.

NO ODOMETRY/ENCODERS USED anywhere.
"""

import math
import json
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from geometry_msgs.msg import Twist

# ---- Tunable constants ----
FAST_DRIVE_SPEED = 0.3          # m/s while wall-following with no gap nearby
SLOW_GAP_SPEED = 0.03           # m/s right before, during, and briefly after a gap
APPROACH_FORWARD_SPEED = 0.15   # m/s while steering toward the door, once committed

GAP_PROXIMITY_THRESHOLD_M = 1.0
GAP_SLOWDOWN_HOLD_SEC = 3.5

WALL_FOLLOW_BEARING_DEG = 90.0
WALL_FOLLOW_WINDOW_DEG = 15.0
WALL_FOLLOW_DESIRED_DISTANCE_M = 1.5
WALL_FOLLOW_GAIN = 0.2
WALL_FOLLOW_MAX_TURN = 0.3

ORIENT_SAMPLE_OFFSET_DEG = 25.0
ORIENT_GAIN = 0.6
ORIENT_MAX_TURN = 0.25

ALIGN_DEADBAND_DEG = 6.0
TURN_GAIN = 0.015
MAX_TURN_SPEED = 0.25
SPIN_ANGULAR_SPEED = 0.3
SPIN_TARGET_DEG = 350.0
SPIN_360_MAX_DURATION_SEC = 60.0  # safety timeout only - stops anyway if scan-matching somehow
                                 # never accumulates to the target (e.g. a perfectly symmetric room
                                 # makes matching ambiguous). The real stopping condition below is
                                 # MEASURED rotation, not this timer.

DECISION_STALE_SEC = 1.0
COMMIT_DURATION_SEC = 20.0      # once committed, keep steering in for this long, then reverse back out
EXTRA_STRAIGHT_DURATION_SEC = 15.0  # after that, go straight for this much longer before reversing

DOORWAY_THRESHOLD_CLOSE_M = 0.4  # obstacle avoidance is only bypassed once this close to a wall/
                                 # frame directly ahead AND well-aligned - kept narrow deliberately
DOORWAY_BYPASS_MAX_BEARING_DEG = 15.0

REFINE_WINDOW_DEG = 30.0        # search +/- this many degrees around the anchor for the actual
                                 # farthest/clearest lidar point
NO_GAP_FALLBACK_CYCLES = 20

HARD_STOP_DISTANCE_M = 0.15
SOFT_SLOW_DISTANCE_M = 0.3
AVOID_TURN_SPEED = 0.3

CONFIRMATIONS_TO_COMMIT = 1

SCAN_STALE_SEC = 0.5

MAX_ANCHOR_DRIFT_DEG = 60.0     # the self-updating steering anchor can't drift arbitrarily far
                                 # from where the door was ORIGINALLY confirmed at commit time -
                                 # near obstacles, a single noisy reading can pull it toward a
                                 # wildly wrong bearing (observed: ~150deg off, nearly behind the
                                 # robot). Any update farther than this is rejected.

STUCK_FRONT_CLEARANCE_M = 0.2
STUCK_CYCLES_THRESHOLD = 15     # ~1.5s at 10Hz
STUCK_BACKUP_SPEED = -0.1
STUCK_BACKUP_DURATION_SEC = 1.5

CONTROL_PERIOD_SEC = 0.1        # matches the control_loop timer rate


class MotionControllerNode(Node):
    def __init__(self):
        super().__init__('motion_controller_node')

        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.decision_sub = self.create_subscription(
            String, '/rover_decision', self.decision_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.latest_scan = None
        self.latest_decision = None
        self.last_decision_time = None
        self.last_scan_receipt_time = None

        self.state = 'DRIVE'   # DRIVE -> APPROACH -> [BACKING_UP if stuck] -> RETURNING -> DONE
        self.locked_bearing_deg = None
        self.initial_commit_bearing_deg = None
        self.no_gap_cycles = 0
        self.stuck_cycles = 0
        self.last_gap_proximity_time = None
        self.commit_start_time = None
        self.extra_straight_start_time = None
        self.spin_start_time = None
        self.spin_cumulative_deg = 0.0
        self.spin_prev_scan = None
        self.backup_start_time = None

        self.recording_active = False
        self.command_history = []
        self.return_plan = []
        self.return_index = 0
        self.return_segment_start = None

        self.control_timer = self.create_timer(0.1, self.control_loop)  # 10 Hz
        self.get_logger().info(
            'Motion controller v10 ready - working steering restored, doorframe-pattern '
            f'check removed, plain {COMMIT_DURATION_SEC:.0f}s commit timer instead.')

    def scan_callback(self, msg):
        self.latest_scan = msg
        self.last_scan_receipt_time = self.get_clock().now()

    def decision_callback(self, msg):
        self.latest_decision = json.loads(msg.data)
        self.last_decision_time = self.get_clock().now()

    def seconds_since(self, ros_time):
        if ros_time is None:
            return float('inf')
        return (self.get_clock().now() - ros_time).nanoseconds / 1e9

    def angle_deg_to_index(self, angle_deg, scan):
        angle_rad = math.radians(angle_deg)
        index = int(round((angle_rad - scan.angle_min) / scan.angle_increment))
        return max(0, min(index, len(scan.ranges) - 1))

    def find_gap_midpoint(self, scan, window_deg=45.0, gap_threshold_m=2.0):
        """Look directly ahead (+/- window_deg) for a gap - a contiguous run of
        readings farther than gap_threshold_m (open space, not a wall close by).
        Returns the angular MIDPOINT of the widest such run (the center of the
        actual opening, not just wherever the single farthest point happens to
        be, which could be off to one side of a wide gap) and its depth at that
        midpoint. Returns (None, None) if no such gap is found."""
        idx_lo = self.angle_deg_to_index(-window_deg, scan)
        idx_hi = self.angle_deg_to_index(window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        best_run_start = None
        best_run_len = 0
        run_start = None
        for i in range(idx_lo, idx_hi + 2):  # +2 so the final run gets closed out below
            r = scan.ranges[i] if i <= idx_hi else None
            is_far = r is not None and math.isfinite(r) and r > gap_threshold_m
            if is_far:
                if run_start is None:
                    run_start = i
            else:
                if run_start is not None:
                    run_len = i - run_start
                    if run_len > best_run_len:
                        best_run_len = run_len
                        best_run_start = run_start
                    run_start = None

        if best_run_start is None:
            return None, None

        run_end = best_run_start + best_run_len - 1
        mid_index = (best_run_start + run_end) // 2
        mid_angle_deg = math.degrees(scan.angle_min + mid_index * scan.angle_increment)
        mid_range = scan.ranges[mid_index]
        return mid_angle_deg, mid_range

    def find_deepest_point(self, scan, center_angle_deg, window_deg, log_diagnostics=False):
        idx_lo = self.angle_deg_to_index(center_angle_deg - window_deg, scan)
        idx_hi = self.angle_deg_to_index(center_angle_deg + window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        best_range = -1.0
        best_angle_deg = center_angle_deg
        raw_slice = scan.ranges[idx_lo:idx_hi + 1]
        for i in range(idx_lo, idx_hi + 1):
            r = scan.ranges[i]
            if math.isfinite(r) and scan.range_min < r < scan.range_max:
                if r > best_range:
                    best_range = r
                    best_angle_deg = math.degrees(scan.angle_min + i * scan.angle_increment)

        if best_range < 0:
            if log_diagnostics:
                finite_count = sum(1 for r in raw_slice if math.isfinite(r))
                self.get_logger().warn(
                    f'find_deepest_point found NOTHING valid: window=[{center_angle_deg - window_deg:.1f}, '
                    f'{center_angle_deg + window_deg:.1f}]deg -> indices [{idx_lo},{idx_hi}] '
                    f'({len(raw_slice)} samples, {finite_count} finite).')
            return None, None
        return best_angle_deg, best_range

    def estimate_rotation_deg(self, prev_scan, curr_scan, max_shift_deg=8.0):
        """Estimate how much the robot rotated between two lidar scans by
        finding the small angular shift that best aligns them - a simplified
        scan-matching technique. This is genuinely MEASURED from the sensor,
        not derived from elapsed time, so it isn't affected by simulation
        real-time-factor varying run to run (which is exactly what made a
        fixed-duration spin cover a different actual angle each time).
        max_shift_deg bounds the search to whatever rotation is plausible in
        one control cycle at the commanded spin rate."""
        n = len(curr_scan.ranges)
        angle_increment_deg = math.degrees(curr_scan.angle_increment)
        if angle_increment_deg <= 0:
            return 0.0
        max_shift_idx = max(1, int(max_shift_deg / angle_increment_deg))

        best_shift = 0
        best_score = None
        for shift in range(-max_shift_idx, max_shift_idx + 1):
            total_sq_diff = 0.0
            count = 0
            for i in range(0, n, 4):  # sample every 4th beam - plenty for alignment, much cheaper
                j = i + shift
                if j < 0 or j >= n:
                    continue
                r_curr = curr_scan.ranges[i]
                r_prev = prev_scan.ranges[j]
                if math.isfinite(r_curr) and math.isfinite(r_prev):
                    diff = r_curr - r_prev
                    total_sq_diff += diff * diff
                    count += 1
            if count < 10:
                continue
            score = total_sq_diff / count
            if best_score is None or score < best_score:
                best_score = score
                best_shift = shift

        if best_score is None:
            return None  # no confident match found - caller should use a fallback estimate,
                         # not silently treat this as "zero rotation this cycle"
        return best_shift * angle_increment_deg

    def get_front_clearance(self, scan, window_deg=15.0):
        idx_lo = self.angle_deg_to_index(-window_deg, scan)
        idx_hi = self.angle_deg_to_index(window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)
        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return float('inf')
        return min(valid_ranges)

    def get_range_at_bearing(self, scan, bearing_deg, window_deg=5.0):
        idx_lo = self.angle_deg_to_index(bearing_deg - window_deg, scan)
        idx_hi = self.angle_deg_to_index(bearing_deg + window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)
        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return None
        return sum(valid_ranges) / len(valid_ranges)

    def get_side_clearance(self, scan, angle_lo_deg, angle_hi_deg):
        idx_lo = self.angle_deg_to_index(angle_lo_deg, scan)
        idx_hi = self.angle_deg_to_index(angle_hi_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)
        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return float('inf')
        return min(valid_ranges)

    def get_side_max_range(self, scan, angle_lo_deg, angle_hi_deg):
        idx_lo = self.angle_deg_to_index(angle_lo_deg, scan)
        idx_hi = self.angle_deg_to_index(angle_hi_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)
        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return 0.0
        return max(valid_ranges)

    def publish_safe(self, cmd):
        scan = self.latest_scan
        scan_is_fresh = self.seconds_since(self.last_scan_receipt_time) < SCAN_STALE_SEC
        if scan is not None and scan_is_fresh and cmd.linear.x > 0:
            front = self.get_front_clearance(scan, window_deg=20.0)

            if front < HARD_STOP_DISTANCE_M:
                left = self.get_side_clearance(scan, 30.0, 90.0)
                right = self.get_side_clearance(scan, -90.0, -30.0)
                turn_toward = 'left' if left > right else 'right'
                cmd = Twist()
                cmd.angular.z = AVOID_TURN_SPEED if left > right else -AVOID_TURN_SPEED
                self.get_logger().warn(
                    f'OBSTACLE AVOIDANCE: front={front:.2f}m too close - stopping, turning {turn_toward}')

            elif front < SOFT_SLOW_DISTANCE_M:
                left = self.get_side_clearance(scan, 30.0, 90.0)
                right = self.get_side_clearance(scan, -90.0, -30.0)
                nudge = AVOID_TURN_SPEED * 0.5 if left > right else -AVOID_TURN_SPEED * 0.5
                cmd.linear.x = min(cmd.linear.x, SLOW_GAP_SPEED)
                cmd.angular.z += nudge
                self.get_logger().info(
                    f'OBSTACLE AVOIDANCE: front={front:.2f}m getting close - slowing, nudging away')

        self.cmd_pub.publish(cmd)
        if self.recording_active:
            self.command_history.append((cmd.linear.x, cmd.angular.z))

    def enter_drive(self):
        self.state = 'DRIVE'
        self.locked_bearing_deg = None
        self.initial_commit_bearing_deg = None
        self.no_gap_cycles = 0
        self.stuck_cycles = 0
        self.recording_active = False

    def begin_commit(self, center_angle_deg):
        self.get_logger().info(
            f'COMMITTED: open door confirmed at bearing={center_angle_deg:.1f}deg. '
            f'Steering in for {COMMIT_DURATION_SEC:.0f}s, then reversing back out. '
            f'Recording every move from here.')
        self.state = 'APPROACH'
        self.locked_bearing_deg = center_angle_deg
        self.initial_commit_bearing_deg = center_angle_deg
        self.commit_start_time = self.get_clock().now()
        self.recording_active = True
        self.command_history = []

    def begin_extra_straight(self):
        self.get_logger().info(
            f'First {COMMIT_DURATION_SEC:.0f}s complete - now going straight for '
            f'{EXTRA_STRAIGHT_DURATION_SEC:.0f}s more before reversing back out.')
        self.state = 'EXTRA_STRAIGHT'
        self.extra_straight_start_time = self.get_clock().now()

    def begin_spin_360(self):
        self.get_logger().info(
            f'Fully inside now - spinning {SPIN_TARGET_DEG:.0f} degrees before starting the return trip, '
            f'MEASURED via lidar scan-matching rather than a fixed duration (a timer covers a '
            f'different actual angle every run, since simulation real-time-factor varies). '
            f'Recording is paused for this spin specifically - it ends facing the same direction '
            f'it started, so it is NOT included in the reversal (unlike the entry maneuver, which '
            f'still gets fully undone).')
        self.recording_active = False
        self.state = 'SPIN_360'
        self.spin_start_time = self.get_clock().now()
        self.spin_cumulative_deg = 0.0
        self.spin_prev_scan = self.latest_scan

    def begin_return(self):
        self.recording_active = False
        self.get_logger().info(
            f'Commit duration complete - retracing {len(self.command_history)} recorded '
            f'commands in reverse to return to the point it committed at.')
        self.state = 'RETURNING'
        self.return_plan = [(-lin, -ang) for (lin, ang) in reversed(self.command_history)]
        self.return_index = 0
        self.return_segment_start = self.get_clock().now()
        self.cmd_pub.publish(Twist())

    def control_loop(self):
        cmd = Twist()

        if self.state == 'RETURNING':
            if self.return_index >= len(self.return_plan):
                self.cmd_pub.publish(Twist())
                self.state = 'DONE'
                self.get_logger().info('RETURN COMPLETE: back at the point it committed at.')
                return
            lin, ang = self.return_plan[self.return_index]
            elapsed = self.seconds_since(self.return_segment_start)
            if elapsed >= CONTROL_PERIOD_SEC:
                self.return_index += 1
                self.return_segment_start = self.get_clock().now()
            else:
                cmd.linear.x = lin
                cmd.angular.z = ang
                self.publish_safe(cmd)
                self.get_logger().info(
                    f'RETURNING: segment {self.return_index + 1}/{len(self.return_plan)} '
                    f'linear={lin:.2f} angular={ang:.2f}')
            return

        if self.state == 'DONE':
            self.cmd_pub.publish(Twist())
            return

        if self.state == 'SPIN_360':
            if self.seconds_since(self.spin_start_time) >= SPIN_360_MAX_DURATION_SEC:
                self.get_logger().warn(
                    f'SPIN 360: safety timeout reached at {self.spin_cumulative_deg:.1f} of {SPIN_TARGET_DEG:.1f}deg '
                    f'measured - returning anyway.')
                self.begin_return()
                return

            if self.latest_scan is not None and self.spin_prev_scan is not None:
                measured = self.estimate_rotation_deg(self.spin_prev_scan, self.latest_scan)
                if measured is not None:
                    step_deg = abs(measured)
                else:
                    # No confident match this cycle (e.g. facing a sparse/open
                    # area with too few valid overlapping readings) - fall back
                    # to the expected rotation at the commanded rate for one
                    # cycle, rather than silently crediting zero. Without this,
                    # occasional failed matches let the cumulative total quietly
                    # fall behind the true rotation, which is what caused the
                    # safety timeout to fire well short of the target before.
                    step_deg = math.degrees(SPIN_ANGULAR_SPEED) * CONTROL_PERIOD_SEC
                self.spin_cumulative_deg += step_deg
                self.spin_prev_scan = self.latest_scan

            if self.spin_cumulative_deg >= SPIN_TARGET_DEG:
                self.get_logger().info(
                    f'SPIN 360 complete - measured {self.spin_cumulative_deg:.1f} degrees via '
                    f'lidar scan-matching.')
                self.begin_return()
                return

            cmd.linear.x = 0.0  # pure rotation - no curving possible
            cmd.angular.z = SPIN_ANGULAR_SPEED
            self.publish_safe(cmd)  # recording_active is False here, so this isn't captured
            self.get_logger().info(
                f'SPIN 360: {self.spin_cumulative_deg:.1f}/{SPIN_TARGET_DEG:.1f}deg measured')
            return

        if self.state == 'EXTRA_STRAIGHT':
            if self.seconds_since(self.extra_straight_start_time) >= EXTRA_STRAIGHT_DURATION_SEC:
                self.begin_spin_360()
                return

            angular_z = 0.0
            gap_bearing = None
            gap_range = None
            if self.latest_scan is not None:
                gap_bearing, gap_range = self.find_gap_midpoint(self.latest_scan)
                if gap_bearing is not None:
                    angular_z = TURN_GAIN * gap_bearing
                    angular_z = max(-MAX_TURN_SPEED, min(MAX_TURN_SPEED, angular_z))

            cmd.linear.x = APPROACH_FORWARD_SPEED
            cmd.angular.z = angular_z
            self.publish_safe(cmd)  # obstacle avoidance still active here too
            gap_str = f'{gap_bearing:.1f}deg (range={gap_range:.2f}m)' if gap_bearing is not None else 'none found'
            self.get_logger().info(
                f'EXTRA STRAIGHT: gap_midpoint={gap_str} angular_z={angular_z:.2f} '
                f'({self.seconds_since(self.extra_straight_start_time):.1f}/{EXTRA_STRAIGHT_DURATION_SEC:.0f}s)')
            return

        if self.state == 'BACKING_UP':
            if self.seconds_since(self.backup_start_time) >= STUCK_BACKUP_DURATION_SEC:
                self.state = 'APPROACH'
                self.stuck_cycles = 0
                self.get_logger().info('Backup complete - resuming.')
                return
            cmd.linear.x = STUCK_BACKUP_SPEED
            cmd.angular.z = 0.0
            self.cmd_pub.publish(cmd)
            if self.recording_active:
                self.command_history.append((cmd.linear.x, cmd.angular.z))
            self.get_logger().warn(
                f'BACKING UP: stuck detected, reversing '
                f'({self.seconds_since(self.backup_start_time):.1f}/{STUCK_BACKUP_DURATION_SEC:.1f}s)')
            return

        if self.state == 'APPROACH':
            if self.seconds_since(self.commit_start_time) >= COMMIT_DURATION_SEC:
                self.begin_extra_straight()
                return

            if self.latest_scan is None:
                self.cmd_pub.publish(Twist())
                return

            front_clearance = self.get_front_clearance(self.latest_scan, window_deg=20.0)
            if front_clearance < STUCK_FRONT_CLEARANCE_M:
                self.stuck_cycles += 1
            else:
                self.stuck_cycles = 0
            if self.stuck_cycles >= STUCK_CYCLES_THRESHOLD:
                self.state = 'BACKING_UP'
                self.backup_start_time = self.get_clock().now()
                self.get_logger().warn(
                    f'STUCK: front clearance under {STUCK_FRONT_CLEARANCE_M}m for '
                    f'{self.stuck_cycles} cycles - backing up before retrying.')
                return

            anchor_bearing = self.locked_bearing_deg if self.locked_bearing_deg is not None else 0.0
            refined_bearing, refined_range = self.find_deepest_point(
                self.latest_scan, anchor_bearing, REFINE_WINDOW_DEG)

            if refined_bearing is None:
                for wider_window in (REFINE_WINDOW_DEG * 2, REFINE_WINDOW_DEG * 3):
                    refined_bearing, refined_range = self.find_deepest_point(
                        self.latest_scan, anchor_bearing, wider_window)
                    if refined_bearing is not None:
                        break

            if refined_bearing is None:
                self.no_gap_cycles += 1
                if self.no_gap_cycles >= NO_GAP_FALLBACK_CYCLES:
                    cmd.linear.x = APPROACH_FORWARD_SPEED * 0.5
                    cmd.angular.z = 0.0
                    self.publish_safe(cmd)
                    self.get_logger().warn(
                        f'APPROACH: no lidar gap for {self.no_gap_cycles} cycles - '
                        f'falling back to last known bearing ({anchor_bearing:.1f}deg).')
                else:
                    self.publish_safe(Twist())
                    self.get_logger().info(
                        f'APPROACH: no valid lidar gap this cycle ({self.no_gap_cycles}/{NO_GAP_FALLBACK_CYCLES}), holding.')
                return

            self.no_gap_cycles = 0

            steering_bearing = refined_bearing
            if self.initial_commit_bearing_deg is not None and \
                    abs(refined_bearing - self.initial_commit_bearing_deg) > MAX_ANCHOR_DRIFT_DEG:
                self.get_logger().warn(
                    f'Rejected anchor update: refined_bearing={refined_bearing:.1f}deg is too far '
                    f'from the original commit bearing ({self.initial_commit_bearing_deg:.1f}deg) - '
                    f'using last trusted anchor for steering instead.')
                steering_bearing = self.locked_bearing_deg if self.locked_bearing_deg is not None \
                    else self.initial_commit_bearing_deg
            else:
                self.locked_bearing_deg = refined_bearing

            if abs(steering_bearing) < ALIGN_DEADBAND_DEG:
                angular_z = 0.0
            else:
                angular_z = TURN_GAIN * steering_bearing
                angular_z = max(-MAX_TURN_SPEED, min(MAX_TURN_SPEED, angular_z))

            cmd.linear.x = APPROACH_FORWARD_SPEED
            cmd.angular.z = angular_z
            if refined_range < DOORWAY_THRESHOLD_CLOSE_M and abs(steering_bearing) < DOORWAY_BYPASS_MAX_BEARING_DEG:
                self.cmd_pub.publish(cmd)
                if self.recording_active:
                    self.command_history.append((cmd.linear.x, cmd.angular.z))
            else:
                self.publish_safe(cmd)
            self.get_logger().info(
                f'APPROACH: gap_bearing={refined_bearing:.1f}deg range={refined_range:.2f}m '
                f'angular_z={angular_z:.2f} '
                f'({self.seconds_since(self.commit_start_time):.1f}/{COMMIT_DURATION_SEC:.0f}s)')
            return

        # DRIVE state: check for a fresh door confirmation first
        decision_is_fresh = self.seconds_since(self.last_decision_time) < DECISION_STALE_SEC
        decision = self.latest_decision.get('decision') if (decision_is_fresh and self.latest_decision) else None
        center_angle_deg = self.latest_decision.get('center_angle_deg') if (decision_is_fresh and self.latest_decision) else None

        if decision == 'ENTER_OPEN_DOOR' and center_angle_deg is not None:
            self.begin_commit(center_angle_deg)
            return

        angular_z = 0.0
        wall_dist = None
        gap_max_dist = None
        gap_seen_this_cycle = False
        orientation_asymmetry = None
        if self.latest_scan is not None:
            wall_dist = self.get_side_clearance(
                self.latest_scan,
                WALL_FOLLOW_BEARING_DEG - WALL_FOLLOW_WINDOW_DEG,
                WALL_FOLLOW_BEARING_DEG + WALL_FOLLOW_WINDOW_DEG)
            if math.isfinite(wall_dist):
                error = wall_dist - WALL_FOLLOW_DESIRED_DISTANCE_M
                angular_z = WALL_FOLLOW_GAIN * error
                angular_z = max(-WALL_FOLLOW_MAX_TURN, min(WALL_FOLLOW_MAX_TURN, angular_z))

            bearing1 = WALL_FOLLOW_BEARING_DEG - ORIENT_SAMPLE_OFFSET_DEG
            bearing2 = WALL_FOLLOW_BEARING_DEG + ORIENT_SAMPLE_OFFSET_DEG
            r1 = self.get_range_at_bearing(self.latest_scan, bearing1)
            r2 = self.get_range_at_bearing(self.latest_scan, bearing2)
            if r1 is not None and r2 is not None:
                y1 = r1 * math.sin(math.radians(bearing1))
                y2 = r2 * math.sin(math.radians(bearing2))
                orientation_asymmetry = y2 - y1
                orient_correction = -ORIENT_GAIN * orientation_asymmetry
                orient_correction = max(-ORIENT_MAX_TURN, min(ORIENT_MAX_TURN, orient_correction))
                angular_z += orient_correction
                angular_z = max(-WALL_FOLLOW_MAX_TURN, min(WALL_FOLLOW_MAX_TURN, angular_z))

            gap_max_dist = self.get_side_max_range(
                self.latest_scan,
                WALL_FOLLOW_BEARING_DEG - WALL_FOLLOW_WINDOW_DEG,
                WALL_FOLLOW_BEARING_DEG + WALL_FOLLOW_WINDOW_DEG)
            if gap_max_dist - WALL_FOLLOW_DESIRED_DISTANCE_M > GAP_PROXIMITY_THRESHOLD_M:
                gap_seen_this_cycle = True

        if gap_seen_this_cycle:
            self.last_gap_proximity_time = self.get_clock().now()
        near_gap = self.seconds_since(self.last_gap_proximity_time) < GAP_SLOWDOWN_HOLD_SEC
        forward_speed = SLOW_GAP_SPEED if near_gap else FAST_DRIVE_SPEED

        cmd.linear.x = forward_speed
        cmd.angular.z = angular_z
        self.publish_safe(cmd)
        wall_dist_str = f'{wall_dist:.2f}m' if wall_dist is not None and math.isfinite(wall_dist) else 'no wall seen'
        gap_max_str = f'{gap_max_dist:.2f}m' if gap_max_dist is not None else 'n/a'
        orient_str = f'{orientation_asymmetry:.2f}m' if orientation_asymmetry is not None else 'n/a'
        self.get_logger().info(
            f'DRIVE (wall-following): wall_dist={wall_dist_str} gap_max_dist={gap_max_str} '
            f'orient_asymmetry={orient_str} '
            f'{"[NEAR GAP - slow]" if near_gap else "[flat wall - fast]"} '
            f'speed={forward_speed:.2f} angular_z={angular_z:.2f}, no door locked yet.')


def main(args=None):
    rclpy.init(args=args)
    node = MotionControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
