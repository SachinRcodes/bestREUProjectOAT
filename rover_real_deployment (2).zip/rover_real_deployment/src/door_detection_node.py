import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import json
import numpy as np
import onnxruntime as ort


# Matches your training label order (door, door frame, door handle, lever).
# If your data.yaml / dataset had a different class order, update this list
# to match exactly - class_id here is purely positional (index into this list).
CLASS_NAMES = ['door', 'door frame', 'door handle', 'lever']


class DoorDetectionNode(Node):
    def __init__(self):
        super().__init__('door_detection_node')
        self.declare_parameter(
            'model_path',
            '/workspace/ros2_ws/src/rover_bringup/config/yolov8m_best.onnx')
        self.declare_parameter('confidence_threshold', 0.5)
        self.declare_parameter('nms_iou_threshold', 0.45)
        self.declare_parameter('target_class', 'door')
        self.declare_parameter('inference_imgsz', 480)
        self.declare_parameter('process_every_n_frames', 2)
        self.declare_parameter('use_clahe', True)

        model_path = self.get_parameter('model_path').value
        self.conf_threshold = self.get_parameter('confidence_threshold').value
        self.nms_iou_threshold = self.get_parameter('nms_iou_threshold').value
        self.target_class = self.get_parameter('target_class').value
        self.inference_imgsz = self.get_parameter('inference_imgsz').value
        self.process_every_n_frames = self.get_parameter('process_every_n_frames').value
        self.use_clahe = self.get_parameter('use_clahe').value
        self.frame_counter = 0

        self.get_logger().info(f'Loading ONNX model from {model_path}')
        # CPUExecutionProvider is the safe default on Jetson Nano's JetPack 4.6.6 /
        # ONNX Runtime combo. If you've built onnxruntime-gpu with CUDA/TensorRT
        # support for this board, add 'CUDAExecutionProvider' or
        # 'TensorrtExecutionProvider' at the FRONT of this list (ORT falls back
        # to the next provider in the list if the first one fails to load).
        self.session = ort.InferenceSession(
            model_path, providers=['CPUExecutionProvider'])
        self.input_name = self.session.get_inputs()[0].name
        input_shape = self.session.get_inputs()[0].shape
        self.get_logger().info(f'Model input: {self.input_name}, shape={input_shape}')
        self.get_logger().info(f'Classes: {CLASS_NAMES}')

        self.clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image, '/camera/image_raw', self.image_callback, 10)
        self.publisher = self.create_publisher(String, '/door_detection', 10)
        self.annotated_publisher = self.create_publisher(
            Image, '/door_detection/annotated_image', 10)

        self.door_color = (0, 255, 0)

        self.get_logger().info(
            f"Door detection node ready (target_class='{self.target_class}', "
            f"confidence_threshold={self.conf_threshold})")

    def preprocess(self, frame):
        """Letterbox-resize to a square inference_imgsz canvas, apply CLAHE,
        and produce the NCHW float32 tensor ONNX Runtime expects.
        Returns (tensor, scale, pad_x, pad_y) so boxes can be mapped back to
        the original frame's coordinates afterward."""
        orig_h, orig_w = frame.shape[:2]
        size = self.inference_imgsz

        scale = min(size / orig_w, size / orig_h)
        new_w, new_h = int(orig_w * scale), int(orig_h * scale)
        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

        pad_x = (size - new_w) // 2
        pad_y = (size - new_h) // 2
        canvas = np.full((size, size, 3), 114, dtype=np.uint8)
        canvas[pad_y:pad_y + new_h, pad_x:pad_x + new_w] = resized

        if self.use_clahe:
            # CLAHE on the L channel only (LAB space) - boosts local contrast
            # without blowing out color, same fix that mattered for your
            # earlier live webcam accuracy.
            lab = cv2.cvtColor(canvas, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            l = self.clahe.apply(l)
            canvas = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)

        img = canvas[:, :, ::-1].astype(np.float32) / 255.0  # BGR->RGB, normalize
        img = img.transpose(2, 0, 1)  # HWC -> CHW
        tensor = np.expand_dims(img, axis=0)  # add batch dim
        return tensor, scale, pad_x, pad_y

    def postprocess(self, output, scale, pad_x, pad_y, orig_w, orig_h):
        """Parses raw YOLOv8 ONNX output: shape (1, 4+num_classes, num_boxes).
        Applies confidence filtering + NMS, then maps boxes back to the
        original (un-letterboxed) frame's pixel coordinates."""
        preds = np.squeeze(output).T  # -> (num_boxes, 4+num_classes)

        boxes_xywh = preds[:, :4]
        class_scores = preds[:, 4:]
        class_ids = np.argmax(class_scores, axis=1)
        confidences = np.max(class_scores, axis=1)

        mask = confidences >= self.conf_threshold
        boxes_xywh = boxes_xywh[mask]
        class_ids = class_ids[mask]
        confidences = confidences[mask]

        if len(boxes_xywh) == 0:
            return []

        # Convert center-xywh (in letterboxed-canvas pixels) to x,y,w,h for NMS
        x_c, y_c, w, h = boxes_xywh[:, 0], boxes_xywh[:, 1], boxes_xywh[:, 2], boxes_xywh[:, 3]
        x1 = x_c - w / 2
        y1 = y_c - h / 2
        boxes_for_nms = np.stack([x1, y1, w, h], axis=1)  # cv2.dnn.NMSBoxes wants x,y,w,h

        indices = cv2.dnn.NMSBoxes(
            boxes_for_nms.tolist(), confidences.tolist(),
            self.conf_threshold, self.nms_iou_threshold)

        detections = []
        if len(indices) > 0:
            for i in np.array(indices).flatten():
                class_id = int(class_ids[i])
                class_name = CLASS_NAMES[class_id] if class_id < len(CLASS_NAMES) else str(class_id)
                if class_name != self.target_class:
                    continue

                # undo letterbox padding + scale to map back to original frame
                cx = (x_c[i] - pad_x) / scale
                cy = (y_c[i] - pad_y) / scale
                bw = w[i] / scale
                bh = h[i] / scale

                detections.append({
                    'class_id': class_id,
                    'class_name': class_name,
                    'confidence': float(confidences[i]),
                    'x_center': float(cx),
                    'y_center': float(cy),
                    'width': float(bw),
                    'height': float(bh),
                })

        return detections

    def draw_boxes(self, frame, detections):
        annotated = frame.copy()
        for det in detections:
            x_c, y_c = det['x_center'], det['y_center']
            w, h = det['width'], det['height']
            x1, y1 = int(x_c - w / 2), int(y_c - h / 2)
            x2, y2 = int(x_c + w / 2), int(y_c + h / 2)

            label = f"{det['class_name']} {det['confidence']:.2f}"

            cv2.rectangle(annotated, (x1, y1), (x2, y2), self.door_color, 2)
            (text_w, text_h), _ = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(annotated, (x1, y1 - text_h - 6),
                          (x1 + text_w, y1), self.door_color, -1)
            cv2.putText(annotated, label, (x1, y1 - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        return annotated

    def image_callback(self, msg):
        self.frame_counter += 1
        if self.frame_counter % self.process_every_n_frames != 0:
            return  # skip this frame entirely - eases CPU load

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        orig_height, orig_width = frame.shape[:2]

        tensor, scale, pad_x, pad_y = self.preprocess(frame)
        output = self.session.run(None, {self.input_name: tensor})[0]
        detections = self.postprocess(output, scale, pad_x, pad_y, orig_width, orig_height)

        stamp_sec = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9

        best_door = None
        if detections:
            best = max(detections, key=lambda d: d['confidence'])
            best_door = {
                'x_center': best['x_center'],
                'width': best['width'],
                'confidence': best['confidence'],
                'image_width': orig_width,
                'stamp_sec': stamp_sec,
            }
            self.get_logger().info(f"Door detected: confidence={best['confidence']:.2f}")

        out_msg = String()
        out_msg.data = json.dumps(best_door) if best_door else json.dumps(
            {'stamp_sec': stamp_sec, 'no_door': True})
        self.publisher.publish(out_msg)

        annotated_frame = self.draw_boxes(frame, detections)
        annotated_msg = self.bridge.cv2_to_imgmsg(annotated_frame, encoding='bgr8')
        annotated_msg.header = msg.header
        self.annotated_publisher.publish(annotated_msg)


def main():
    rclpy.init()
    node = DoorDetectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
