import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from collections import deque
import json
import math


class DecisionNode(Node):
    def __init__(self):
        super().__init__('decision_node')

        self.declare_parameter('camera_fov_deg', 60.0)  # MUST match model.sdf's horizontal_fov
        self.declare_parameter('depth_difference_threshold', 0.3)
        self.declare_parameter('surround_padding_deg', 10.0)
        self.declare_parameter('max_time_sync_diff', 0.3)
        self.declare_parameter('scan_buffer_size', 30)
        self.declare_parameter('max_door_width_m', 1.3)  # wider than this = probably a wall, not a door
        self.declare_parameter('camera_mount_yaw_offset_deg', 90.0)  # camera is mounted rotated relative
                                 # to chassis-forward (facing sideways at the wall while the chassis
                                 # drives parallel to it) - this offset converts camera-relative bearings
                                 # into the chassis/lidar's shared reference frame

        self.camera_fov_deg = self.get_parameter('camera_fov_deg').value
        self.depth_threshold = self.get_parameter('depth_difference_threshold').value
        self.surround_padding_deg = self.get_parameter('surround_padding_deg').value
        self.max_time_sync_diff = self.get_parameter('max_time_sync_diff').value
        buffer_size = self.get_parameter('scan_buffer_size').value
        self.max_door_width_m = self.get_parameter('max_door_width_m').value
        self.camera_mount_yaw_offset_deg = self.get_parameter('camera_mount_yaw_offset_deg').value

        self.scan_buffer = deque(maxlen=buffer_size)

        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10)
        self.detection_sub = self.create_subscription(
            String, '/door_detection', self.detection_callback, 10)
        self.decision_pub = self.create_publisher(String, '/rover_decision', 10)

        self.get_logger().info('Decision node ready (time-synchronized)')

    def scan_callback(self, msg):
        stamp_sec = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        self.scan_buffer.append((stamp_sec, msg))

    def find_matching_scan(self, target_stamp):
        if not self.scan_buffer:
            return None

        best_scan = None
        best_diff = None
        for stamp_sec, scan in self.scan_buffer:
            diff = abs(stamp_sec - target_stamp)
            if best_diff is None or diff < best_diff:
                best_diff = diff
                best_scan = scan

        if best_diff is not None and best_diff <= self.max_time_sync_diff:
            return best_scan
        return None

    def pixel_to_angle_deg(self, x_center, image_width):
        normalized = (x_center / image_width) - 0.5
        camera_relative_angle = normalized * self.camera_fov_deg
        # Convert from camera-relative bearing to the chassis/lidar's shared
        # frame, since the camera is mounted rotated relative to chassis-forward.
        return camera_relative_angle + self.camera_mount_yaw_offset_deg

    def angle_to_scan_index(self, angle_deg, scan):
        angle_rad = math.radians(angle_deg)
        index = int((angle_rad - scan.angle_min) / scan.angle_increment)
        return max(0, min(index, len(scan.ranges) - 1))

    def get_average_range(self, scan, center_angle_deg, half_width_deg):
        angles = [center_angle_deg - half_width_deg, center_angle_deg + half_width_deg]
        idx1 = self.angle_to_scan_index(angles[0], scan)
        idx2 = self.angle_to_scan_index(angles[1], scan)
        lo, hi = min(idx1, idx2), max(idx1, idx2)
        valid_ranges = [r for r in scan.ranges[lo:hi + 1]
                         if scan.range_min < r < scan.range_max and not math.isinf(r)]
        if not valid_ranges:
            return None
        return sum(valid_ranges) / len(valid_ranges)

    def detection_callback(self, msg):
        detection = json.loads(msg.data)

        if detection is None or detection.get('no_door'):
            self.publish_decision('NO_DOOR_DETECTED', None, None, None)
            return

        detection_stamp = detection.get('stamp_sec')
        if detection_stamp is None:
            self.get_logger().warn('Detection missing timestamp, cannot sync with lidar')
            self.publish_decision('MISSING_TIMESTAMP', None, None, None)
            return

        scan = self.find_matching_scan(detection_stamp)
        if scan is None:
            self.get_logger().warn(
                f'No lidar scan within {self.max_time_sync_diff}s of detection '
                f'timestamp — skipping this decision to avoid using stale data')
            self.publish_decision('NO_SYNCED_LIDAR_DATA', None, None, None)
            return

        x_center = detection['x_center']
        width = detection['width']
        image_width = detection['image_width']

        center_angle = self.pixel_to_angle_deg(x_center, image_width)
        half_width_angle = self.pixel_to_angle_deg(x_center + width / 2, image_width) - \
            self.pixel_to_angle_deg(x_center, image_width)

        door_depth = self.get_average_range(scan, center_angle, abs(half_width_angle))

        if door_depth is not None:
            # Convert the detection's angular width, at the measured depth, into an
            # actual physical width. A flat wall filling the camera view can trigger
            # a false "door" detection - but a real door is never wider than ~1.3m,
            # while a wall segment often spans several meters. This uses the lidar
            # (ground truth distance) rather than the image alone, since a wide
            # object far away and a narrow object close up can look identical in
            # pixels but have very different physical widths.
            physical_width_m = 2.0 * door_depth * math.tan(math.radians(abs(half_width_angle)))
            if physical_width_m > self.max_door_width_m:
                self.get_logger().info(
                    f'Rejected detection: physical_width={physical_width_m:.2f}m exceeds '
                    f'max_door_width_m={self.max_door_width_m}m - likely a wall, not a door.')
                self.publish_decision('NOT_A_DOOR_TOO_WIDE', door_depth, None, center_angle)
                return

        left_wall_depth = self.get_average_range(
            scan, center_angle - abs(half_width_angle) - self.surround_padding_deg / 2,
            self.surround_padding_deg / 2)
        right_wall_depth = self.get_average_range(
            scan, center_angle + abs(half_width_angle) + self.surround_padding_deg / 2,
            self.surround_padding_deg / 2)

        wall_depths = [d for d in [left_wall_depth, right_wall_depth] if d is not None]

        if door_depth is None or not wall_depths:
            self.get_logger().info(
                f'INSUFFICIENT_LIDAR_DATA: door_depth={door_depth}, '
                f'left_wall={left_wall_depth}, right_wall={right_wall_depth}, '
                f'center_angle={center_angle:.1f}deg - not enough valid lidar '
                f'readings around this detection to classify it.')
            self.publish_decision('INSUFFICIENT_LIDAR_DATA', door_depth, wall_depths, center_angle)
            return

        avg_wall_depth = sum(wall_depths) / len(wall_depths)
        depth_difference = door_depth - avg_wall_depth

        if abs(depth_difference) > self.depth_threshold:
            decision = 'ENTER_OPEN_DOOR'
            direction_note = 'receding (opens away)' if depth_difference > 0 \
                else 'protruding (opens toward robot)'
        else:
            decision = 'DOOR_CLOSED_OR_BLOCKED'
            direction_note = 'flush with wall'

        self.get_logger().info(
            f'door_depth={door_depth:.2f}m wall_depth={avg_wall_depth:.2f}m '
            f'diff={depth_difference:+.2f}m ({direction_note}) -> {decision} '
            f'center_angle={center_angle:.1f}deg')

        self.publish_decision(decision, door_depth, avg_wall_depth, center_angle)

    def publish_decision(self, decision, door_depth, wall_depth, center_angle_deg):
        out = {
            'decision': decision,
            'door_depth': door_depth,
            'wall_depth': wall_depth,
            'center_angle_deg': center_angle_deg,  # ADDED: bearing to the detected door, needed for steering
        }
        msg = String()
        msg.data = json.dumps(out)
        self.decision_pub.publish(msg)


def main():
    rclpy.init()
    node = DecisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
