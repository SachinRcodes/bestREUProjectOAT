#!/usr/bin/env python3
"""
Motion controller v7 - wall-following, no spinning.

DRIVE behavior (no door locked on): drives forward while using the lidar to
hold a steady standoff distance from the wall on its left side (a classic
wall-following P-controller: measure distance to the wall, steer toward it
if too far, away if too close). The chassis travels PARALLEL to the wall -
it never rotates to face it. Since a differential-drive robot can only
move along its own heading, seeing the wall at all while traveling parallel
to it requires the CAMERA to be mounted rotated 90 degrees relative to the
chassis (see the rover model) - so the chassis drives straight down the
wall's length while the camera independently looks sideways at it the whole
time. decision_node.py adds a matching offset when converting camera pixel
bearings into bearings, so everything downstream still shares one consistent
chassis/lidar reference frame.

The rover starts far to one side of the house and wall-follows its way
across the whole front, so it doesn't need to already be aligned with a
specific door - see the world file's rover spawn pose.

COMMIT: a SINGLE ENTER_OPEN_DOOR reading is enough to commit (no
multi-confirmation needed) - spinning was what made detection noisy before;
without it, one clean reading is trustworthy. Once committed, the anchor
bearing self-updates from the lidar's own clearest-point result every cycle
(not the camera), so it keeps tracking the gap all the way through even if
the door leaves the camera's narrow FOV up close, or detection drops out
entirely afterward.

OBSTACLE AVOIDANCE: applied universally, every cycle, right before any
forward-moving command is published. If something is very close directly
ahead, forward motion is cancelled and the rover turns away from it (toward
whichever side has more clearance). If moderately close, it slows and nudges
away while still progressing.

NO ODOMETRY/ENCODERS USED anywhere - every decision comes from the current
lidar scan and the current camera-derived decision only.
"""

import math
import json
import random
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from geometry_msgs.msg import Twist

# ---- Tunable constants ----
FAST_DRIVE_SPEED = 0.2          # m/s while wall-following with no gap nearby
SLOW_GAP_SPEED = 0.03           # m/s right before, during, and briefly after a gap
APPROACH_FORWARD_SPEED = 0.15   # m/s while steering into a confirmed open door's gap

GAP_PROXIMITY_THRESHOLD_M = 1.0  # if the wall reading is farther than desired by more than this,
                                 # a gap is nearby - start slowing down
GAP_SLOWDOWN_HOLD_SEC = 3.5      # once a gap is seen, keep the slow speed for at least this long
                                 # after the last time it was seen - covers "a little after" the
                                 # gap, not just the instant it's detected. Extended to buy more
                                 # real-world detection margin, since sim real-time-factor can dip
                                 # well below 1.0 under CPU load, making a fixed sim-time window
                                 # translate to less actual wall-clock time than expected

WALL_FOLLOW_BEARING_DEG = 90.0   # the wall is on the robot's left (chassis/lidar frame)
WALL_FOLLOW_WINDOW_DEG = 15.0    # +/- window around that bearing to measure wall distance
WALL_FOLLOW_DESIRED_DISTANCE_M = 1.5  # target standoff distance from the wall
WALL_FOLLOW_GAIN = 0.2           # rad/s of correction per meter of distance error
WALL_FOLLOW_MAX_TURN = 0.3       # rad/s cap on the wall-following correction

ALIGN_DEADBAND_DEG = 6.0        # within this bearing error, drive dead straight (no correction)
TURN_GAIN = 0.015               # gentle proportional gain outside the deadband
MAX_TURN_SPEED = 0.25           # capped low so it's a gentle curve, never a spin

ENTRY_STOP_RANGE_M = 0.5        # stop once this close to the door
DECISION_STALE_SEC = 1.0        # a single /rover_decision message this old is "no longer trustworthy"
APPROACH_GRACE_SEC = 2.5        # once locked on (but not yet committed), tolerate this long without
                                 # a fresh ENTER_OPEN_DOOR before giving up on this particular reading

REFINE_WINDOW_DEG = 30.0        # search +/- this many degrees around the anchor bearing for the
                                 # actual farthest/clearest lidar point - the real passable gap,
                                 # which is often NOT at the camera bbox's geometric center
                                 # (especially with an angled hinged door)
NO_GAP_FALLBACK_CYCLES = 20      # after this many consecutive cycles finding nothing (even with
                                 # widened windows), stop holding forever and drive along the last
                                 # known bearing instead - at 10Hz this is ~2 seconds

HARD_STOP_DISTANCE_M = 0.2       # anything this close directly ahead - stop and turn away
SOFT_SLOW_DISTANCE_M = 0.4       # anything this close - slow down and nudge away, but keep going
AVOID_TURN_SPEED = 0.3           # rad/s used when actively turning away from an obstacle

CONFIRMATIONS_TO_COMMIT = 1      # a single ENTER_OPEN_DOOR is enough - no spinning means no noisy
                                 # bearing jitter to guard against anymore

SCAN_STALE_SEC = 0.5             # obstacle avoidance refuses to trust a lidar scan older than this -
                                 # verifies it's always reacting to genuinely current lidar data, not
                                 # a leftover reading from a moment ago

# --- "At the gap" marker: the lidar pattern of a doorway threshold - two near
# readings flanking (the door posts/frame) and a far reading dead ahead (open
# space beyond) ---
SIDE_CHECK_BEARING_DEG = 40.0    # roughly where the door posts appear, this close to the opening
SIDE_CHECK_WINDOW_DEG = 20.0
SIDE_NEAR_MAX_M = 1.0            # a "post nearby" reading
FRONT_CHECK_WINDOW_DEG = 15.0
FRONT_FAR_MIN_M = 1.2            # a "deep space ahead" reading

# --- Random exploration once inside, then reverse back to the marked gap ---
EXPLORE_DURATION_SEC = 15.0
EXPLORE_FORWARD_SPEED = 0.1
EXPLORE_MAX_TURN = 0.3
EXPLORE_TURN_CHANGE_INTERVAL_SEC = 2.0

CONTROL_PERIOD_SEC = 0.1         # matches the control_loop timer rate - every recorded command
                                 # ran for exactly this long


class MotionControllerNode(Node):
    def __init__(self):
        super().__init__('motion_controller_node')

        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.decision_sub = self.create_subscription(
            String, '/rover_decision', self.decision_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.latest_scan = None
        self.latest_decision = None
        self.last_decision_time = None
        self.last_scan_receipt_time = None

        self.state = 'DRIVE'   # DRIVE -> APPROACH -> EXPLORING -> RETURNING -> DONE
        self.locked_bearing_deg = None
        self.last_open_door_time = None
        self.open_door_confirmations = 0
        self.committed = False
        self.no_gap_cycles = 0
        self.last_gap_proximity_time = None

        # Exploration + reversal-based return, starting from the marked gap point
        self.command_history = []
        self.explore_start_time = None
        self.explore_next_turn_time = None
        self.explore_angular = 0.0
        self.return_plan = []
        self.return_index = 0
        self.return_segment_start = None

        self.control_timer = self.create_timer(0.1, self.control_loop)  # 10 Hz
        self.get_logger().info(
            'Motion controller v6 ready - no spinning, drives straight, '
            'commits on first open-door detection.')

    def scan_callback(self, msg):
        self.latest_scan = msg
        self.last_scan_receipt_time = self.get_clock().now()

    def decision_callback(self, msg):
        self.latest_decision = json.loads(msg.data)
        self.last_decision_time = self.get_clock().now()

    def seconds_since(self, ros_time):
        if ros_time is None:
            return float('inf')
        return (self.get_clock().now() - ros_time).nanoseconds / 1e9

    def angle_deg_to_index(self, angle_deg, scan):
        angle_rad = math.radians(angle_deg)
        index = int(round((angle_rad - scan.angle_min) / scan.angle_increment))
        return max(0, min(index, len(scan.ranges) - 1))

    def find_deepest_point(self, scan, center_angle_deg, window_deg, log_diagnostics=False):
        """Within [center_angle_deg - window, center_angle_deg + window], find the
        bearing with the maximum valid lidar range - the actual clearest open
        path, which may not line up with the camera's bbox center at all."""
        idx_lo = self.angle_deg_to_index(center_angle_deg - window_deg, scan)
        idx_hi = self.angle_deg_to_index(center_angle_deg + window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        best_range = -1.0
        best_angle_deg = center_angle_deg
        raw_slice = scan.ranges[idx_lo:idx_hi + 1]
        for i in range(idx_lo, idx_hi + 1):
            r = scan.ranges[i]
            if math.isfinite(r) and scan.range_min < r < scan.range_max:
                if r > best_range:
                    best_range = r
                    best_angle_deg = math.degrees(scan.angle_min + i * scan.angle_increment)

        if best_range < 0:
            if log_diagnostics:
                finite_count = sum(1 for r in raw_slice if math.isfinite(r))
                self.get_logger().warn(
                    f'find_deepest_point found NOTHING valid: window=[{center_angle_deg - window_deg:.1f}, '
                    f'{center_angle_deg + window_deg:.1f}]deg -> indices [{idx_lo},{idx_hi}] '
                    f'({len(raw_slice)} samples, {finite_count} finite). '
                    f'range_min={scan.range_min}, range_max={scan.range_max}. '
                    f'Sample raw values: {list(raw_slice[:5])}...{list(raw_slice[-5:])}')
            return None, None
        return best_angle_deg, best_range

    def get_front_clearance(self, scan, window_deg=15.0):
        idx_lo = self.angle_deg_to_index(-window_deg, scan)
        idx_hi = self.angle_deg_to_index(window_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return float('inf')
        return min(valid_ranges)

    def get_side_clearance(self, scan, angle_lo_deg, angle_hi_deg):
        idx_lo = self.angle_deg_to_index(angle_lo_deg, scan)
        idx_hi = self.angle_deg_to_index(angle_hi_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return float('inf')
        return min(valid_ranges)

    def get_side_max_range(self, scan, angle_lo_deg, angle_hi_deg):
        """Farthest (not nearest) valid reading in this window. Used specifically
        for gap detection: only ONE beam needs to see deep space to correctly
        flag an opening, even if other beams in the same window still graze a
        door frame's edge - using the minimum here (like get_side_clearance)
        would mask the gap entirely whenever partial occlusion happens, which
        is exactly what made gap detection inconsistent run-to-run."""
        idx_lo = self.angle_deg_to_index(angle_lo_deg, scan)
        idx_hi = self.angle_deg_to_index(angle_hi_deg, scan)
        idx_lo, idx_hi = min(idx_lo, idx_hi), max(idx_lo, idx_hi)

        valid_ranges = [scan.ranges[i] for i in range(idx_lo, idx_hi + 1)
                         if math.isfinite(scan.ranges[i]) and scan.range_min < scan.ranges[i] < scan.range_max]
        if not valid_ranges:
            return 0.0
        return max(valid_ranges)

    def is_at_gap(self, scan):
        """The lidar pattern of being right at a doorway threshold: two near
        readings flanking (the door posts/frame) and a far reading dead ahead
        (open space in the room beyond). This is the geometric definition of
        'I am now in the gap' - used to mark this exact point before exploring."""
        left_near = self.get_side_clearance(
            scan, SIDE_CHECK_BEARING_DEG - SIDE_CHECK_WINDOW_DEG,
            SIDE_CHECK_BEARING_DEG + SIDE_CHECK_WINDOW_DEG)
        right_near = self.get_side_clearance(
            scan, -SIDE_CHECK_BEARING_DEG - SIDE_CHECK_WINDOW_DEG,
            -SIDE_CHECK_BEARING_DEG + SIDE_CHECK_WINDOW_DEG)
        front_far = self.get_side_max_range(
            scan, -FRONT_CHECK_WINDOW_DEG, FRONT_CHECK_WINDOW_DEG)

        pattern_confirmed = (
            left_near < SIDE_NEAR_MAX_M and
            right_near < SIDE_NEAR_MAX_M and
            front_far > FRONT_FAR_MIN_M)

        self.get_logger().info(
            f'is_at_gap check: left_near={left_near:.2f}m right_near={right_near:.2f}m '
            f'front_far={front_far:.2f}m -> pattern_confirmed={pattern_confirmed}')
        return pattern_confirmed

    def publish_safe(self, cmd):
        """Universal obstacle-avoidance filter - applies regardless of state.
        Refuses to trust a stale scan (SCAN_STALE_SEC) - if the lidar hasn't
        reported anything recently, treat it the same as having no scan at all
        rather than acting on an old reading."""
        scan = self.latest_scan
        scan_is_fresh = self.seconds_since(self.last_scan_receipt_time) < SCAN_STALE_SEC
        if scan is not None and scan_is_fresh and cmd.linear.x > 0:
            front = self.get_front_clearance(scan, window_deg=20.0)

            if front < HARD_STOP_DISTANCE_M:
                left = self.get_side_clearance(scan, 30.0, 90.0)
                right = self.get_side_clearance(scan, -90.0, -30.0)
                turn_toward = 'left' if left > right else 'right'
                cmd = Twist()
                cmd.angular.z = AVOID_TURN_SPEED if left > right else -AVOID_TURN_SPEED
                self.get_logger().warn(
                    f'OBSTACLE AVOIDANCE: front={front:.2f}m too close - stopping, turning {turn_toward}')

            elif front < SOFT_SLOW_DISTANCE_M:
                left = self.get_side_clearance(scan, 30.0, 90.0)
                right = self.get_side_clearance(scan, -90.0, -30.0)
                nudge = AVOID_TURN_SPEED * 0.5 if left > right else -AVOID_TURN_SPEED * 0.5
                cmd.linear.x = min(cmd.linear.x, SLOW_GAP_SPEED)
                cmd.angular.z += nudge
                self.get_logger().info(
                    f'OBSTACLE AVOIDANCE: front={front:.2f}m getting close - slowing, nudging away')

        self.cmd_pub.publish(cmd)
        if self.state == 'EXPLORING':
            self.command_history.append((cmd.linear.x, cmd.angular.z))

    def enter_drive(self):
        self.state = 'DRIVE'
        self.locked_bearing_deg = None
        self.last_open_door_time = None
        self.open_door_confirmations = 0
        self.committed = False
        self.no_gap_cycles = 0

    def begin_explore(self):
        """Reached the opening. Mark this exact point using the lidar's doorway
        pattern (informational - proceeds either way, since requiring a perfect
        pattern match could get stuck waiting on an imperfect angle), then start
        recording commands and wander randomly for a while, obstacle avoidance
        fully active throughout."""
        pattern_confirmed = self.is_at_gap(self.latest_scan) if self.latest_scan is not None else False
        self.get_logger().info(
            f'MARKED: at the gap (doorway pattern confirmed={pattern_confirmed}) - '
            f'beginning tracked random exploration.')
        self.state = 'EXPLORING'
        self.command_history = []
        now = self.get_clock().now()
        self.explore_start_time = now
        self.explore_next_turn_time = now
        self.explore_angular = random.uniform(-EXPLORE_MAX_TURN, EXPLORE_MAX_TURN)
        self.cmd_pub.publish(Twist())

    def begin_return_from_explore(self):
        """Exploration time is up - replay the recorded commands in reverse,
        with both linear.x and angular.z negated for each entry, to retrace
        the exact path back to the marked gap point."""
        self.get_logger().info(
            f'Exploration complete - retracing {len(self.command_history)} recorded '
            f'commands in reverse to return to the marked gap point.')
        self.state = 'RETURNING'
        self.return_plan = [(-lin, -ang) for (lin, ang) in reversed(self.command_history)]
        self.return_index = 0
        self.return_segment_start = self.get_clock().now()
        self.cmd_pub.publish(Twist())

    def control_loop(self):
        cmd = Twist()

        if self.state == 'EXPLORING':
            if self.seconds_since(self.explore_start_time) >= EXPLORE_DURATION_SEC:
                self.begin_return_from_explore()
                return

            if self.seconds_since(self.explore_next_turn_time) >= EXPLORE_TURN_CHANGE_INTERVAL_SEC:
                self.explore_angular = random.uniform(-EXPLORE_MAX_TURN, EXPLORE_MAX_TURN)
                self.explore_next_turn_time = self.get_clock().now()

            cmd.linear.x = EXPLORE_FORWARD_SPEED
            cmd.angular.z = self.explore_angular
            self.publish_safe(cmd)  # obstacle avoidance fully active, records into command_history
            self.get_logger().info(
                f'EXPLORING: angular={self.explore_angular:.2f} '
                f'({self.seconds_since(self.explore_start_time):.1f}/{EXPLORE_DURATION_SEC:.1f}s)')
            return

        if self.state == 'RETURNING':
            if self.return_index >= len(self.return_plan):
                self.cmd_pub.publish(Twist())
                self.state = 'DONE'
                self.get_logger().info('RETURN COMPLETE: back at the marked gap point.')
                return

            lin, ang = self.return_plan[self.return_index]
            elapsed = self.seconds_since(self.return_segment_start)
            if elapsed >= CONTROL_PERIOD_SEC:
                self.return_index += 1
                self.return_segment_start = self.get_clock().now()
            else:
                cmd.linear.x = lin
                cmd.angular.z = ang
                self.cmd_pub.publish(cmd)  # exact replay - not publish_safe
                self.get_logger().info(
                    f'RETURNING: segment {self.return_index + 1}/{len(self.return_plan)} '
                    f'linear={lin:.2f} angular={ang:.2f}')
            return

        if self.state == 'DONE':
            self.cmd_pub.publish(Twist())
            return

        decision_is_fresh = self.seconds_since(self.last_decision_time) < DECISION_STALE_SEC
        decision = self.latest_decision.get('decision') if (decision_is_fresh and self.latest_decision) else None
        center_angle_deg = self.latest_decision.get('center_angle_deg') if (decision_is_fresh and self.latest_decision) else None

        if decision == 'ENTER_OPEN_DOOR' and center_angle_deg is not None:
            self.locked_bearing_deg = center_angle_deg
            self.last_open_door_time = self.get_clock().now()
            self.state = 'APPROACH'
            if not self.committed:
                self.open_door_confirmations += 1
                self.get_logger().info(
                    f'Open door confirmation {self.open_door_confirmations}/{CONFIRMATIONS_TO_COMMIT}')
                if self.open_door_confirmations >= CONFIRMATIONS_TO_COMMIT:
                    self.committed = True
                    self.get_logger().info(
                        'COMMITTED: open door confirmed - now navigating by lidar alone.')

        if decision == 'DOOR_CLOSED_OR_BLOCKED' and self.state == 'APPROACH' and not self.committed:
            self.enter_drive()

        if self.state == 'APPROACH':
            grace_expired = (not self.committed) and (
                self.seconds_since(self.last_open_door_time) > APPROACH_GRACE_SEC)
            if grace_expired:
                self.enter_drive()
            elif self.latest_scan is None:
                self.cmd_pub.publish(Twist())
            else:
                anchor_bearing = self.locked_bearing_deg if self.locked_bearing_deg is not None else 0.0
                refined_bearing, refined_range = self.find_deepest_point(
                    self.latest_scan, anchor_bearing, REFINE_WINDOW_DEG)

                if refined_bearing is None:
                    # Try progressively wider windows before giving up - the opening
                    # may have shifted slightly out of the original window as the
                    # chassis rotates toward it.
                    for wider_window in (REFINE_WINDOW_DEG * 2, REFINE_WINDOW_DEG * 3):
                        refined_bearing, refined_range = self.find_deepest_point(
                            self.latest_scan, anchor_bearing, wider_window)
                        if refined_bearing is not None:
                            self.get_logger().info(
                                f'APPROACH: found gap only with widened window ({wider_window:.0f}deg)')
                            break

                if refined_bearing is None:
                    self.no_gap_cycles += 1
                    if self.no_gap_cycles >= NO_GAP_FALLBACK_CYCLES:
                        # Genuinely stuck - drive straight along the last known
                        # anchor bearing at reduced speed rather than freeze forever.
                        # Obstacle avoidance (publish_safe) still protects against
                        # collision if this heads somewhere bad.
                        cmd.linear.x = APPROACH_FORWARD_SPEED * 0.5
                        cmd.angular.z = 0.0
                        self.publish_safe(cmd)
                        self.get_logger().warn(
                            f'APPROACH: no lidar gap for {self.no_gap_cycles} cycles - '
                            f'falling back to driving along last known bearing '
                            f'({anchor_bearing:.1f}deg) at reduced speed.')
                        return
                    else:
                        self.find_deepest_point(self.latest_scan, anchor_bearing,
                                                 REFINE_WINDOW_DEG, log_diagnostics=True)
                        self.cmd_pub.publish(Twist())
                        self.get_logger().info(
                            f'APPROACH: no valid lidar gap found this cycle '
                            f'({self.no_gap_cycles}/{NO_GAP_FALLBACK_CYCLES}), holding.')
                        return

                self.no_gap_cycles = 0

                if refined_range < ENTRY_STOP_RANGE_M:
                    self.begin_explore()
                    return

                if self.committed:
                    self.locked_bearing_deg = refined_bearing

                if abs(refined_bearing) < ALIGN_DEADBAND_DEG:
                    angular_z = 0.0
                else:
                    angular_z = TURN_GAIN * refined_bearing
                    angular_z = max(-MAX_TURN_SPEED, min(MAX_TURN_SPEED, angular_z))

                cmd.linear.x = APPROACH_FORWARD_SPEED
                cmd.angular.z = angular_z
                # NOT publish_safe here - find_deepest_point already steers toward
                # the farthest clear direction (obstacle avoidance "by construction").
                # The generic front-clearance check conflicts with this once actually
                # threading a doorway, since the frame/wall edges legitimately sit
                # close on either side even when correctly centered and safely
                # passing through - that produces a stuck oscillation (avoidance
                # fights the steering, neither making progress) rather than an
                # actual collision risk.
                self.cmd_pub.publish(cmd)
                self.get_logger().info(
                    f'APPROACH{" [COMMITTED]" if self.committed else ""}: '
                    f'gap_bearing={refined_bearing:.1f}deg range={refined_range:.2f}m '
                    f'angular_z={angular_z:.2f}')
                return

        # DRIVE: wall-following. Measure distance to the wall on the left (chassis/
        # lidar frame) and steer to hold a steady standoff while advancing - never
        # rotates to face the wall, the camera (mounted sideways) handles looking
        # at it independently of chassis heading.
        #
        # Speed: fast by default. If the wall reading is much farther than normal
        # (a gap/doorway - the beam is passing through into the room beyond),
        # that's "approaching a gap" - slow down. Stays slow for a hold period
        # after the last such reading too, so the slowdown naturally covers
        # right before, during, and briefly after passing the gap - not just
        # the single instant it's detected.
        angular_z = 0.0
        wall_dist = None
        gap_max_dist = None
        gap_seen_this_cycle = False
        if self.latest_scan is not None:
            wall_dist = self.get_side_clearance(
                self.latest_scan,
                WALL_FOLLOW_BEARING_DEG - WALL_FOLLOW_WINDOW_DEG,
                WALL_FOLLOW_BEARING_DEG + WALL_FOLLOW_WINDOW_DEG)
            if math.isfinite(wall_dist):
                error = wall_dist - WALL_FOLLOW_DESIRED_DISTANCE_M  # +ve = too far, steer toward wall
                angular_z = WALL_FOLLOW_GAIN * error
                angular_z = max(-WALL_FOLLOW_MAX_TURN, min(WALL_FOLLOW_MAX_TURN, angular_z))

            # Separate check for gap PRESENCE uses the farthest beam in the window,
            # not the nearest - see get_side_max_range's docstring for why.
            gap_max_dist = self.get_side_max_range(
                self.latest_scan,
                WALL_FOLLOW_BEARING_DEG - WALL_FOLLOW_WINDOW_DEG,
                WALL_FOLLOW_BEARING_DEG + WALL_FOLLOW_WINDOW_DEG)
            if gap_max_dist - WALL_FOLLOW_DESIRED_DISTANCE_M > GAP_PROXIMITY_THRESHOLD_M:
                gap_seen_this_cycle = True

        if gap_seen_this_cycle:
            self.last_gap_proximity_time = self.get_clock().now()
        near_gap = self.seconds_since(self.last_gap_proximity_time) < GAP_SLOWDOWN_HOLD_SEC
        forward_speed = SLOW_GAP_SPEED if near_gap else FAST_DRIVE_SPEED

        cmd.linear.x = forward_speed
        cmd.angular.z = angular_z
        self.publish_safe(cmd)
        wall_dist_str = f'{wall_dist:.2f}m' if wall_dist is not None and math.isfinite(wall_dist) else 'no wall seen'
        gap_max_str = f'{gap_max_dist:.2f}m' if gap_max_dist is not None else 'n/a'
        self.get_logger().info(
            f'DRIVE (wall-following): wall_dist={wall_dist_str} gap_max_dist={gap_max_str} '
            f'{"[NEAR GAP - slow]" if near_gap else "[flat wall - fast]"} '
            f'speed={forward_speed:.2f} angular_z={angular_z:.2f}, no door locked yet.')


def main(args=None):
    rclpy.init(args=args)
    node = MotionControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
