import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
from ultralytics import YOLO
import cv2
import json


class DoorDetectionNode(Node):
    def __init__(self):
        super().__init__('door_detection_node')
        self.declare_parameter(
            'model_path',
            '/mnt/c/Users/golir/Door_detection/Dataset_All/labeled_all_new/'
            'Dataset_ALL/results/yolov8m_doors_640px_75e_16b/weights/best.pt')
        self.declare_parameter('confidence_threshold', 0.5)
        self.declare_parameter('target_class', 'door')
        self.declare_parameter('inference_imgsz', 480)  # compromise between speed and accuracy -
                                 # full 640px + every frame was pushing CPU too hard, causing
                                 # inconsistent real-time factor and flaky detection timing
        self.declare_parameter('process_every_n_frames', 2)  # light skip - eases load while still
                                 # catching roughly half the frames during each pass

        model_path = self.get_parameter('model_path').value
        self.conf_threshold = self.get_parameter('confidence_threshold').value
        self.target_class = self.get_parameter('target_class').value
        self.inference_imgsz = self.get_parameter('inference_imgsz').value
        self.process_every_n_frames = self.get_parameter('process_every_n_frames').value
        self.frame_counter = 0

        self.get_logger().info(f'Loading YOLO model from {model_path}')
        self.model = YOLO(model_path)
        # self.model.names is a dict like {0: 'door', 1: 'door frame', ...} - comes
        # from the model itself, so no need to hardcode class_names separately.
        self.get_logger().info(f'Model loaded. Classes: {self.model.names}')

        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image, '/camera/image_raw', self.image_callback, 10)
        self.publisher = self.create_publisher(String, '/door_detection', 10)
        self.annotated_publisher = self.create_publisher(
            Image, '/door_detection/annotated_image', 10)

        self.door_color = (0, 255, 0)

        self.get_logger().info(
            f"Door detection node ready (target_class='{self.target_class}', "
            f"confidence_threshold={self.conf_threshold})")

    def run_inference(self, frame):
        """Runs YOLO on a frame, returns detections for target_class only,
        in the same dict format the rest of the pipeline (decision_node) expects."""
        results = self.model(frame, imgsz=self.inference_imgsz, verbose=False)[0]
        detections = []

        for box in results.boxes:
            class_id = int(box.cls[0])
            class_name = self.model.names[class_id]
            confidence = float(box.conf[0])

            if confidence < self.conf_threshold:
                continue
            if class_name != self.target_class:
                continue

            x_center, y_center, w, h = box.xywh[0].tolist()
            detections.append({
                'class_id': class_id,
                'class_name': class_name,
                'confidence': confidence,
                'x_center': x_center,
                'y_center': y_center,
                'width': w,
                'height': h,
            })

        return detections

    def draw_boxes(self, frame, detections):
        annotated = frame.copy()
        for det in detections:
            x_c, y_c = det['x_center'], det['y_center']
            w, h = det['width'], det['height']
            x1, y1 = int(x_c - w / 2), int(y_c - h / 2)
            x2, y2 = int(x_c + w / 2), int(y_c + h / 2)

            label = f"{det['class_name']} {det['confidence']:.2f}"

            cv2.rectangle(annotated, (x1, y1), (x2, y2), self.door_color, 2)
            (text_w, text_h), _ = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(annotated, (x1, y1 - text_h - 6),
                          (x1 + text_w, y1), self.door_color, -1)
            cv2.putText(annotated, label, (x1, y1 - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        return annotated

    def image_callback(self, msg):
        self.frame_counter += 1
        if self.frame_counter % self.process_every_n_frames != 0:
            return  # skip this frame entirely - eases CPU load

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        orig_height, orig_width = frame.shape[:2]

        detections = self.run_inference(frame)

        stamp_sec = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9

        best_door = None
        if detections:
            best = max(detections, key=lambda d: d['confidence'])
            best_door = {
                'x_center': best['x_center'],
                'width': best['width'],
                'confidence': best['confidence'],
                'image_width': orig_width,
                'stamp_sec': stamp_sec,
            }
            self.get_logger().info(f"Door detected: confidence={best['confidence']:.2f}")

        out_msg = String()
        out_msg.data = json.dumps(best_door) if best_door else json.dumps(
            {'stamp_sec': stamp_sec, 'no_door': True})
        self.publisher.publish(out_msg)

        annotated_frame = self.draw_boxes(frame, detections)
        annotated_msg = self.bridge.cv2_to_imgmsg(annotated_frame, encoding='bgr8')
        annotated_msg.header = msg.header
        self.annotated_publisher.publish(annotated_msg)


def main():
    rclpy.init()
    node = DoorDetectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
