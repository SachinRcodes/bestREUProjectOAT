import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Path to this scaffold's own files (adjust if you move the folder)
    pkg_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    world_path = os.path.join(pkg_dir, 'worlds', 'door_world.sdf')
    bridge_config = os.path.join(pkg_dir, 'config', 'bridge.yaml')
    models_path = os.path.join(pkg_dir, 'models')

    # Make sure gz sim can find the rover model via model://rover
    gz_resource_env = os.environ.copy()
    gz_resource_env['GZ_SIM_RESOURCE_PATH'] = models_path + os.pathsep + \
        gz_resource_env.get('GZ_SIM_RESOURCE_PATH', '')

    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_path],
        additional_env=gz_resource_env,
        output='screen'
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='ros_gz_bridge',
        parameters=[{'config_file': bridge_config}],
        output='screen'
    )

    return LaunchDescription([gazebo, bridge])
